from flask import Flask, request, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, or_
from flask_restful import Resource, Api
from flask_jwt_extended import create_access_token, JWTManager, get_jwt_identity, jwt_required
from werkzeug.security import generate_password_hash, check_password_hash
from celery_worker import make_celery
from httplib2 import Http
from json import dumps
from flask_mail import Mail
from flask_mail import Message
from celery.schedules import crontab
from celery.result import AsyncResult
from flask_caching import Cache
import time
import csv
from datetime import timedelta
import smtplib
import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

app = Flask(__name__)

app.config['SECRET_KEY'] = 'SUPER-SECRET-KEY'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'

app.config.update(
    CELERY_BROKER_URL='redis://localhost:6380',
    CELERY_RESULT_BACKEND='redis://localhost:6380',
    CACHE_TYPE='redis',
    CACHE_REDIS_HOST="localhost",
    CACHE_REDIS_PORT=6380,
    CACHE_REDIS_DB = 3,
    CACHE_DEFAULT_TIMEOUT=300,

)

db = SQLAlchemy(app)
api = Api(app)
jwt = JWTManager(app)
mail = Mail(app)
cache = Cache(app)

celery = make_celery(app)

@celery.task()
def add_together(a, b):
    return a + b

@celery.task()
def send_remainder():
    
    #users = user.query.all
    # current_time = datetime.datetime.now()
    users = User.query.all()

    for use in users:
        if use.role != "admin" and use.timestamp <= (datetime.datetime.now() - timedelta(hours=24)):
            url =  "https://chat.googleapis.com/v1/spaces/AAAAOj2gZNI/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=7kzteGf712-YFuqBU0yESi-CcUM5De5GY4O6CDwATMk"
            bot_message = {
                'text': f"Hello {use.username}, you have not logged in for 24 hours!. Please visit our app and Explore Music like never before!!"
            }
            message_headers = {'Content-Type': 'application/json; charset=UTF-8'}
            http_obj = Http()
            response = http_obj.request(
                uri=url,
                method='POST',
                headers=message_headers,
                body=dumps(bot_message),
            )
            print(response)

@celery.on_after_configure.connect
def setup_daily_reminder(sender, **kwargs):
    sender.add_periodic_task(30.0,
        # crontab(hour=11, minute=30),
        send_remainder.s(),
        name='daily-remainder-chat'
    )

@celery.on_after_configure.connect
def setup_monthly_report(sender, **kwargs):
    sender.add_periodic_task(30.0,
        # crontab(hour=11, minute=30, day_of_month='28'),
        send_monthly_creator_reports.s(),
    )

SMPTP_SERVER_HOST = "localhost"
SMPTP_SERVER_PORT = 1025
SENDER_ADDRESS= "MusicMagnet@gmail.com"
SENDER_PASSWORD =""

def send_email(to_address, subject, message, content="text", attachment_file=None):
    msg = MIMEMultipart()
    msg["From"] = SENDER_ADDRESS  # This can be a dummy address for MailHog
    msg["To"] = to_address
    msg["Subject"] = subject

    if content == "html":
        msg.attach(MIMEText(message, "html"))
    else:
        msg.attach(MIMEText(message, "plain"))

    if attachment_file:
        with open(attachment_file, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename= {attachment_file}')
            msg.attach(part)

    s = smtplib.SMTP(host="localhost", port=1025)  # Default MailHog SMTP configuration
    s.send_message(msg)
    s.quit()
    return True

@celery.task
def send_monthly_creator_reports():
    today = datetime.datetime.now()
    first_day_of_previous_month = today.replace(day=1) - timedelta(days=1)
    first_day_of_previous_month = first_day_of_previous_month.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    creators = User.query.filter_by(role='creator').all()

    for creator in creators:
        new_songs = Song.query.filter(Song.creator_id == creator.id, Song.timestamp >= first_day_of_previous_month).all()
        new_albums = Album.query.filter(Album.creator_id == creator.id, Album.timestamp >= first_day_of_previous_month).all()

        if new_songs or new_albums:
            subject = "Your Monthly Activity Report"
            message = f"<html><body><h2>Hello {creator.username},</h2>"
            message += "<p>Here is your activity report for the last month:</p>"

            if new_songs:
                message += "<h3>New Songs:</h3><ul>"
                for song in new_songs:
                    message += f"<li>{song.name} - Average Rating: {song.average_rating:.2f}</li>"
                message += "</ul>"

            if new_albums:
                message += "<h3>New Albums:</h3><ul>"
                for album in new_albums:
                    message += f"<li>{album.name}</li>"
                message += "</ul>"

            message += "</body></html>"

            send_email(to_address=creator.email, subject=subject, message=message, content="html")

    return "Monthly creator reports sent successfully."

@celery.task()
def generate_csv(updated_song_names=None):
    time.sleep(6)  # Simulate some processing time
    fields = ['Name', 'Lyrics', 'Genre', 'Duration']

    songs = Song.query.all()

    rows = []
    for song in songs:
        rows.append([song.name, song.lyrics, song.genre, song.duration])

    with open("static/songsdata.csv", 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(rows)

    return "CSV generation completed"

# Flask route to trigger CSV generation task
@app.route("/trigger_csv_generation", methods=["GET", "POST"])
def trigger_csv_generation():
    # Assume you have some logic to update song names
    # If not, pass an empty dictionary
    updated_song_names = {
        "song1": "Updated Name 1",
        "song2": "Updated Name 2",
        "song3": "Updated Name 3",
        "song4": "Updated Name 4",
        "song5": "Updated Name 5",
        "song6": "Updated Name 6"
    }
    
    generate_csv.delay(updated_song_names)
    
    return "CSV generation task triggered successfully."

# Flask route to check task status
@app.route("/status/<id>")
def check_status(id):
    res = generate_csv.AsyncResult(id)
    
    return {
        "Task ID": res.id,
        "Task State": res.state,
        "Task Result": res.result
    }

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    role = db.Column(db.String, nullable=False, default='user')
    timestamp = db.Column(db.DateTime, default=datetime.datetime.now())
    active = db.Column(db.Boolean, default=True)  
    playlists = db.relationship('Playlist', backref='user', lazy=True)
    creator_password_hash = db.Column(db.String(128), nullable=True)

    def __repr__(self):
        return f"User('{self.username}', '{self.email}', '{self.role}', '{self.active}')"


class Album(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    artist = db.Column(db.String(100), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.now())
    creator_id = db.Column(db.Integer, nullable=False)
    flagged = db.Column(db.Boolean, default=False)  # New column for flagging
    songs = db.relationship('Song', backref='album', lazy=True)

    def serialize(self):
        return {
            'id': self.id,
            'name': self.name,
            'artist': self.artist,
            'creator_id': self.creator_id,
            'flagged': self.flagged,
            'songs': [song.serialize() for song in self.songs] if self.songs else []
        }

class Song(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    lyrics = db.Column(db.Text, nullable=False)
    genre = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.String(20), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.now())
    creator_id = db.Column(db.Integer, nullable=False)
    album_id = db.Column(db.Integer, db.ForeignKey('album.id'), nullable=True)
    total_rating = db.Column(db.Float, default=0)
    rating_count = db.Column(db.Integer, default=0)
    flagged = db.Column(db.Boolean, default=False)  # New column for flagging

    @property
    def average_rating(self):
        if self.rating_count == 0:
            return 0
        return self.total_rating / self.rating_count
    
    @property
    def total_plays(self):
        return len(self.playlists)  # Assuming each playlist addition represents a play

    @property
    def total_likes(self):
        return len(self.playlists)  # Assuming each playlist addition represents a like

    @property
    def total_comments(self):
        return len(self.playlists)  # Assuming each playlist addition represents a comment

      

    def serialize(self):
        return {
            'id': self.id,
            'name': self.name,
            'lyrics': self.lyrics,
            'genre': self.genre,
            'duration': self.duration,
            'creator_id': self.creator_id,
            'album_id': self.album_id if self.album_id is not None else 0,
            'average_rating': self.average_rating,
            'flagged': self.flagged,
            'total_plays': self.total_plays,
            'total_likes': self.total_likes,
            'total_comments': self.total_comments

        }

class Playlist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    songs = db.relationship('Song', secondary='playlist_songs', backref='playlists')

playlist_songs = db.Table('playlist_songs',
                          db.Column('playlist_id', db.Integer, db.ForeignKey('playlist.id'), primary_key=True),
                          db.Column('song_id', db.Integer, db.ForeignKey('song.id'), primary_key=True)
                          )

with app.app_context():
    db.create_all()

class UserRegistration(Resource):
    def post(self):
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        role = data.get('role', 'user')  # Accepts 'user' or 'creator'.
        creator_password = data.get('creator_password', None)

        if not username or not password or not email or not role:
            return {'message': 'Missing username, password, email, or role'}, 400

        existing_user = User.query.filter_by(username=username).first()

        if existing_user:
            # If the user exists, validate password before updating
            if not check_password_hash(existing_user.password, password):
                return {'message': 'Incorrect password'}, 401

            # If the user is changing role to creator
            if role == 'creator':
                if existing_user.role != 'user':
                    return {'message': 'Cannot change role to creator. User role is not set.'}, 400

                # Set the creator password if provided
                if creator_password:
                    existing_user.creator_password_hash = generate_password_hash(creator_password)
                else:
                    return {'message': 'Creator password is required to change role to creator'}, 400

            existing_user.role = role

            db.session.commit()
            return {'message': 'User updated successfully'}, 200
        else:
            new_user = User(username=username, email=email, role=role)
            if role == 'creator':
                if not creator_password:
                    return {'message': 'Creator password is required to register as a creator'}, 400
                new_user.password = generate_password_hash(password)
                new_user.creator_password_hash = generate_password_hash(creator_password)
            else:
                # If registering as a user, generate only user password
                new_user.password = generate_password_hash(password)

            db.session.add(new_user)
            db.session.commit()
            return {'message': 'User created successfully'}, 200


class UserLogin(Resource):
    def post(self):
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return {'message': 'Invalid credentials'}, 400  # Bad Request

        user = User.query.filter_by(username=username).first()

        if not user:
            return {'message': 'User not found'}, 404  # User not found

        role = user.role
        if role == 'admin':
            if not check_password_hash(user.password, password):
                return {'message': 'Invalid credentials'}, 401  # Unauthorized
        elif role == 'user':
            if not check_password_hash(user.password, password):
                return {'message': 'Invalid credentials'}, 401  # Unauthorized
        elif role == 'creator':
            if check_password_hash(user.password, password):
                role = 'user'
            elif check_password_hash(user.creator_password_hash, password):
                role = 'creator'
            else:
                return {'message': 'Invalid credentials'}, 401  # Unauthorized

        user.timestamp = datetime.datetime.now()
        db.session.commit()


        access_token = create_access_token(identity=user.id)
        return {'message': 'Login successful', 'access_token': access_token, 'role': role}, 200


class SongResource(Resource):
    @jwt_required()
    def post(self):
        try:
            current_user_id = get_jwt_identity()
            data = request.get_json()
            required_fields = ['name', 'lyrics', 'genre', 'duration', 'album_id']
            for field in required_fields:
                if field not in data:
                    return {'message': f'Missing field: {field}'}, 400

            existing_song = Song.query.filter_by(name=data['name']).first()
            if existing_song:
                return {'message': 'A song with the same name already exists'}, 400

            new_song = Song(
                name=data['name'],
                lyrics=data['lyrics'],
                genre=data['genre'],
                duration=data['duration'],
                timestamp=datetime.datetime.now(),
                creator_id=current_user_id,
                album_id=data['album_id']
            )
            db.session.add(new_song)
            db.session.commit()
            return {'message': 'Song created successfully'}, 201
        except Exception as e:
            return {'message': 'Failed to create song', 'error': str(e)}, 500

    @jwt_required()
    @cache.memoize(timeout=50)
    def get(self):
        try:
            role = request.headers.get('Role')  # Assuming role is sent in the request headers
            current_user_id = get_jwt_identity()
            
            if role == 'admin' or role == 'user':
                songs = Song.query.all()
            else:
                songs = Song.query.filter_by(creator_id=current_user_id).all()
                
            serialized_songs = [song.serialize() for song in songs]
            return serialized_songs, 200
        except Exception as e:
            return {'message': 'Failed to fetch songs', 'error': str(e)}, 500
        
    @jwt_required()
    def put(self, song_id):
        try:
            current_user_id = get_jwt_identity()
            song = Song.query.get(song_id)
            if not song:
                return {'message': 'Song not found'}, 404
            if song.creator_id != current_user_id:
                return {'message': 'You are not authorized to edit this song'}, 403
            data = request.get_json()
            song.name = data.get('name', song.name)
            song.lyrics = data.get('lyrics', song.lyrics)
            song.genre = data.get('genre', song.genre)
            song.duration = data.get('duration', song.duration)
            song.album_id = data.get('album_id', song.album_id)
            db.session.commit()
            return {'message': 'Song updated successfully'}, 200
        except Exception as e:
            return {'message': 'Failed to update song', 'error': str(e)}, 500

    @jwt_required()
    def delete(self, song_id):
        try:
            current_user_id = get_jwt_identity()
            current_user = User.query.get(current_user_id)
            
            song = Song.query.get(song_id)
            if not song:
                return {'message': 'Song not found'}, 404
            
            if song.creator_id == current_user_id or current_user.role == 'admin':
                db.session.delete(song)
                db.session.commit()
                return {'message': 'Song deleted successfully'}, 200
            else:
                return {'message': 'Unauthorized to delete this song'}, 403

        except Exception as e:
            return {'message': 'Failed to delete song', 'error': str(e)}, 500

class AlbumResource(Resource):
    @jwt_required()
    def post(self):
        try:
            current_user_id = get_jwt_identity()
            data = request.get_json()

            # Check if all required fields are present in the request data
            required_fields = ['name', 'artist']
            for field in required_fields:
                if field not in data:
                    return {'message': f'Missing field: {field}'}, 400

            # Check if an album with the same name already exists
            existing_album = Album.query.filter_by(name=data['name']).first()
            if existing_album:
                return {'message': 'An album with the same name already exists'}, 400

            # Check if 'song_id' is present and ensure it's in a list
            song_ids = data.get('song_id')
            if song_ids is not None:
                # Assuming song_ids should be a list of IDs. If it's just one id, wrap it in a list.
                song_ids = [song_ids] if isinstance(song_ids, int) else song_ids
            else:
                # If no song_id is provided, default to an empty list
                song_ids = []

            # Create a new album with the provided data
            new_album = Album(
                name=data['name'],
                artist=data['artist'],
                timestamp=datetime.datetime.now(),
                songs=song_ids,  # Assuming your Album model can handle a list of song IDs
                creator_id=current_user_id
            )
            db.session.add(new_album)
            db.session.commit()
            return {'message': 'Album created successfully'}, 201
        except Exception as e:
            return {'message': 'Failed to create album', 'error': str(e)}, 500

    @jwt_required()
    @cache.memoize(timeout=50)
    def get(self):
        try:
            role = request.headers.get('Role')  # Assuming role is sent in the request headers
            current_user_id = get_jwt_identity()
            
            if role == 'admin' or role == 'user':
                albums = Album.query.all()
            else:
                albums = Album.query.filter_by(creator_id=current_user_id).all()
                
            serialized_albums = [album.serialize() for album in albums]
            return serialized_albums, 200
        except Exception as e:
            return {'message': 'Failed to fetch albums', 'error': str(e)}, 500
        
    @jwt_required()
    def put(self, album_id):
        try:
            current_user_id = get_jwt_identity()
            album = Album.query.get(album_id)
            if not album:
                return {'message': 'Album not found'}, 404
            if album.creator_id != current_user_id:
                return {'message': 'You are not authorized to edit this album'}, 403
            data = request.get_json()
            album.name = data.get('name', album.name)
            album.artist = data.get('artist', album.artist)
            
            song_ids = data.get('song_ids', [])
            for song_id in song_ids:
                song = Song.query.get(song_id)
                if song:  # Add the song if it exists
                    if song not in album.songs:  # Ensure the song is not already associated with the album
                        album.songs.append(song)
            
            db.session.commit()
            return {'message': 'Album updated successfully'}, 200
        except Exception as e:
            return {'message': 'Failed to update album', 'error': str(e)}, 500

    @jwt_required()
    def delete(self, album_id):
        try:
            current_user_id = get_jwt_identity()
            current_user = User.query.get(current_user_id)
            album = Album.query.get(album_id)
            if not album:
                return {'message': 'Album not found'}, 404
            if album.creator_id == current_user_id or current_user.role == 'admin':
                
                db.session.delete(album)
                db.session.commit()
                return {'message': 'Album deleted successfully'}, 200
            else:
                return {'message': 'You are not authorized to delete this album'}, 403
        except Exception as e:
            return {'message': 'Failed to delete album', 'error': str(e)}, 500

        
class SingleAlbumResource(Resource):
    @jwt_required()
    @cache.memoize(timeout=50)
    def get(self, album_id):
        try:
            album = Album.query.filter_by(id=album_id).first()
            if not album:
                return {'message': 'Album not found'}, 404
            serialized_album = album.serialize()
            return serialized_album, 200
        except Exception as e:
            return {'message': 'Failed to fetch album', 'error': str(e)}, 500

class SingleSongResource(Resource):
    @jwt_required()
    def get(self, song_id):
        try:
            song = Song.query.filter_by(id=song_id).first()
            if not song:
                return {'message': 'Song not found'}, 404
            serialized_song = song.serialize()
            return serialized_song, 200
        except Exception as e:
            return {'message': 'Failed to fetch song', 'error': str(e)}, 500

class SearchResource(Resource):
    def get(self):
        search_query = request.args.get('q')
        min_rating = request.args.get('min_rating')

        if not search_query:
            return {'message': 'No search query provided'}, 400

        # Filter songs based on search query and minimum rating
        songs_query = Song.query.filter(or_(Song.name.ilike(f'%{search_query}%'), 
                                             Song.lyrics.ilike(f'%{search_query}%'), 
                                             Song.genre.ilike(f'%{search_query}%')))
        if min_rating:
            min_rating = float(min_rating)  # Parse min_rating as float
            songs_query = songs_query.filter(Song.average_rating >= min_rating)  # Access average_rating directly
        songs = songs_query.all()

        # Filter albums based on search query and artists
        albums_query = Album.query.filter(or_(Album.name.ilike(f'%{search_query}%'), 
                                              Album.artist.ilike(f'%{search_query}%')))
        albums = albums_query.all()
        
        serialized_songs = [song.serialize() for song in songs]
        serialized_albums = [album.serialize() for album in albums]
        return {'songs': serialized_songs, 'albums': serialized_albums}, 200
class PlaylistResource(Resource):
    @jwt_required()
    def post(self):
        current_user_id = get_jwt_identity()
        data = request.get_json()

        if 'song_id' not in data:
            return {'message': 'Missing field: song_id'}, 400

        song_id = data['song_id']
        song = Song.query.get(song_id)
        if not song:
            return {'message': 'Song not found'}, 404

        user = User.query.get(current_user_id)
        if not user:
            return {'message': 'User not found'}, 404

        playlist = Playlist.query.filter_by(user_id=user.id).first()
        if not playlist:
            playlist = Playlist(user_id=user.id)
            db.session.add(playlist)
            db.session.commit()

        if song not in playlist.songs:
            playlist.songs.append(song)
            db.session.commit()
            return {'message': 'Song added to playlist successfully'}, 200
        else:
            return {'message': 'Song already in playlist'}, 400
        
    @jwt_required()
    def get(self):
        try:
            current_user_id = get_jwt_identity()
            playlist = Playlist.query.filter_by(user_id=current_user_id).first()
            if not playlist:
                return {'message': 'Playlist not found for the current user'}, 404
            playlist_songs = playlist.songs
            serialized_songs = [song.serialize() for song in playlist_songs]
            return serialized_songs, 200
        except Exception as e:
            # Log the error
            print("Error fetching playlist songs:", str(e))
            return {'message': 'Failed to fetch playlist songs', 'error': str(e)}, 500
        
class RateSong(Resource):
    @jwt_required()
    def post(self, song_id):
        try:
            current_user_id = get_jwt_identity()
            rating = float(request.json.get('rating'))
            song = Song.query.get(song_id)
            if not song:
                return {'message': 'Song not found'}, 404
            song.total_rating += rating
            song.rating_count += 1
            db.session.commit()
            return {'message': 'Song rated successfully'}, 200

        except Exception as e:
            # Log the error
            print("Error rating song:", str(e))
            return {'message': 'Failed to rate song', 'error': str(e)}, 500
        
class FlagResource(Resource):
    @jwt_required()
    def post(self, item_type, item_id):
        try:
            current_user_id = get_jwt_identity()
            if item_type == 'song':
                item = Song.query.get(item_id)
            elif item_type == 'album':
                item = Album.query.get(item_id)
            else:
                return {'message': 'Invalid item type'}, 400
            if not item:
                return {'message': 'Item not found'}, 404
            item.flagged = True
            db.session.commit()
            return {'message': 'Item flagged successfully'}, 200

        except Exception as e:
            print("Error flagging item:", str(e))
            return {'message': 'Failed to flag item', 'error': str(e)}, 500

class AdminStatisticsResource(Resource):
    @jwt_required()
    def get(self):
        current_user = get_jwt_identity()
        user = User.query.get(current_user)
        if user.role != 'admin':
            return {'message': 'Unauthorized'}, 403
        
        stats = {
            'total_users': User.query.count(),
            'total_creators': User.query.filter_by(role='creator').count(),
            'total_albums': Album.query.count(),
            'total_songs': Song.query.count(),
        }
        
        return stats, 200
    


        
api.add_resource(UserRegistration,'/register')
api.add_resource(UserLogin, '/login')
api.add_resource(SongResource, '/song','/song/<int:song_id>')
api.add_resource(AlbumResource, '/album','/album/<int:album_id>')
api.add_resource(SingleAlbumResource, '/album_view/<int:album_id>')
api.add_resource(SingleSongResource, '/song_view/<int:song_id>')
api.add_resource(SearchResource, '/search')
api.add_resource(PlaylistResource, '/playlist', '/playlist/songs')
api.add_resource(RateSong, '/rate_song/<int:song_id>')
api.add_resource(FlagResource, '/flag/<string:item_type>/<int:item_id>')
api.add_resource(AdminStatisticsResource, '/admin/statistics')

@app.route('/')
def index():
    return render_template('index.html')

if __name__=="__main__":
    with app.app_context():
        if not User.query.filter_by(username='admin').first():
            # Create admin user if not already present
            hashed_password = generate_password_hash('admin_password')
            admin_user = User(username='admin', email='admin@example.com', password=hashed_password, role='admin')
            db.session.add(admin_user)
            new_song = Song(name="Sample Song", lyrics="Sample lyrics", genre="Pop", duration="30", creator_id=1, album_id=None)
            db.session.add(new_song)
            db.session.commit()
            
    app.run(debug=True)
