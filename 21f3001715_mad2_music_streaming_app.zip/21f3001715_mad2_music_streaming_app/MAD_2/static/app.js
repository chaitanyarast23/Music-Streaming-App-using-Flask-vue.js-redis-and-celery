import router from './router.js'



// Main Vue instance
new Vue({
    el: '#app',
    template: `
        
        <router-view/>
        `,
        router,
    
});
