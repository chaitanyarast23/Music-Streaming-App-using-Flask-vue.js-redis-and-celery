export default {
  data() {
    return {
      album: null
    };
  },
  mounted() {
    this.fetchAlbum();
  },
  methods: {
    fetchAlbum() {
      const albumId = this.$route.params.id;
      axios.get(`/album_view/${albumId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          this.album = response.data;
        })
        .catch(error => {
          console.error('Error fetching album:', error);
        });
    },
    flagAlbum() {
      axios.post(`/flag/album/${this.album.id}`, {}, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          alert('Album flagged successfully!');
        })
        .catch(error => {
          console.error('Error flagging album:', error);
          alert('Failed to flag album. Please try again later.');
        });
    },
    viewSong(song) {
      this.$router.push({ name: 'song_view', params: { id: song.id } });
    },
  },
  template: `
    <div>
      <!-- Album Details -->
      <div class="container mt-5" v-if="album">
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">{{ album.name }}</h2>
            <p class="card-text">Artist: {{ album.artist }}</p>
          </div>
          <div class="card-body">
            <ul class="list-group">
              <li v-for="song in album.songs" :key="song.id" class="list-group-item d-flex justify-content-between align-items-center">
                {{ song.name }}
                <button class="btn btn-primary" @click="viewSong(song)">View</button>
              </li>
            </ul>
          </div>
          <div class="card-footer">
            <button @click="flagAlbum" class="btn btn-danger">Flag Album</button>
          </div>
        </div>
      </div>
    </div>
  `
};
