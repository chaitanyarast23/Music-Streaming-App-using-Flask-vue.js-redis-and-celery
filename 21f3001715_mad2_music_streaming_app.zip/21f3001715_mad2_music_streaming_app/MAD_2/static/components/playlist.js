export default {
  data() {
    return {
      playlistSongs: []  // New data property to store playlist songs
    };
  },
  mounted() {
    this.fetchPlaylistSongs();
  },
  methods: {
    fetchPlaylistSongs() {
      const token = localStorage.getItem('access_token');
      fetch(`/playlist/songs`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch playlist songs');
        }
        return response.json();
      })
      .then(data => {
        this.playlistSongs = data;
      })
      .catch(error => {
        console.error('Error fetching playlist songs:', error);
      });
    },
    viewSong(song) {
      this.$router.push({ name: 'song_view', params: { id: song.id } });
    },
  },
  template: `
  <div class="container mt-5">
    <h2>Playlist Songs</h2>
    <div class="row">
      <div v-for="song in playlistSongs" :key="song.id" class="col-lg-4 mb-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">{{ song.name }}</h5>
            
            <button class="btn btn-primary" @click="viewSong(song)">View</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  `
};
