export default {
  data() {
    return {
      song: null,
      rating: null,
      songId: this.$route.params.id,
      playlistSongs: []
    };
  },
  mounted() {
    this.fetchSong();
  },
  methods: {
    fetchSong() {
      axios.get(`/song_view/${this.songId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          this.song = response.data;
        })
        .catch(error => {
          console.error('Error fetching song:', error);
        });
    },
    addToPlaylist() {
      axios.post('/playlist', { song_id: this.songId }, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          alert('Song added to playlist successfully!');
        })
        .catch(error => {
          console.error('Error adding song to playlist:', error);
          alert('Failed to add song to playlist. Please try again later.');
        });
    },
    rateSong() {
      const token = localStorage.getItem('access_token');
      axios.post(`/rate_song/${this.songId}`, { rating: this.rating }, { headers: { Authorization: `Bearer ${token}` } })
        .then(response => {
          alert('Song rated successfully!');
          this.rating = null;
          this.fetchSong();
        })
        .catch(error => {
          console.error('Error rating song:', error);
          alert('Failed to rate song. Please try again later.');
        });
    },
    flagSong() {
      axios.post(`/flag/song/${this.songId}`, {}, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          alert('Song flagged successfully!');
        })
        .catch(error => {
          console.error('Error flagging song:', error);
          alert('Failed to flag song. Please try again later.');
        });
    }
  },
  template: `
    <div class="container mt-5" v-if="song">
      <div class="card">
        <div class="card-body">
          <h2 class="card-title">{{ song.name }}</h2>
          <p class="card-text"><strong>Genre:</strong> {{ song.genre }}</p>
          <p class="card-text"><strong>Lyrics:</strong> {{ song.lyrics }}</p>
          <p class="card-text"><strong>Duration:</strong> {{ song.duration }} seconds</p>
          <p><strong>Rating:</strong> {{ song.average_rating }}</p>
          <p>Rate this song:</p>
          <input type="number" v-model="rating" min="1" max="5" step="1">
          <button @click="rateSong" class="btn btn-primary">Rate</button>
          <br>
          <button @click="addToPlaylist" class="btn btn-primary mt-2">Add to Playlist</button>
          <button @click="flagSong" class="btn btn-danger mt-2">Flag</button> <!-- Added flag button -->
        </div>
      </div>
    </div>
  `
};
