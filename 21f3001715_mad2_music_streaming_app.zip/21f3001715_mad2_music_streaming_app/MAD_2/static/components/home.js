export default {
  data() {
    return {
      songs: [],
      albums: [],
      searchQuery: ''
    };
  },
  mounted() {
    this.fetchSongs();
    this.fetchAlbums();
    
  },
  methods: {
    fetchSongs() {
      const token = localStorage.getItem('access_token');
      const role = 'user'; // Change this to the actual role value if needed
      fetch('/song', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Role': role
        }
      })
        .then(response => response.json())
        .then(data => {
          this.songs = data;
        })
        .catch(error => {
          console.error('Error fetching songs:', error);
        });
    },
    fetchAlbums() {
      const token = localStorage.getItem('access_token');
      const role = 'user'; // Change this to the actual role value if needed
      fetch('/album', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Role': role
        }
      })
        .then(response => response.json())
        .then(data => {
          this.albums = data;
        })
        .catch(error => {
          console.error('Error fetching albums:', error);
        });
    },
    search() {
      const token = localStorage.getItem('access_token');
      const role = 'user'; // Change this to the actual role value if needed
      
      // Send a request to your backend API with the search query
      fetch(`/search?q=${this.searchQuery}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Role': role
        }
      })
        .then(response => response.json())
        .then(data => {
          // Update the songs and albums data with the search results
          this.songs = data.songs;
          this.albums = data.albums;
        })
        .catch(error => {
          console.error('Error searching:', error);
        });
    },
    viewSong(song) {
      // Navigate to the view song page
      this.$router.push({ name: 'song_view', params: { id: song.id } });
    },
    viewAlbum(album) {
      // Navigate to the view album page
      this.$router.push({ name: 'album_view', params: { id: album.id } });
    },
    logout() {
      // Clear the access token from local storage
      localStorage.removeItem('access_token');
      // Redirect to the login page
      this.$router.push('/login');
    }
  },
  template: `
  <div>
  <!-- Navbar content -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <router-link to="/" class="navbar-brand">Music Magnet</router-link>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <div class="input-group input-group-sm">
          <input type="text" class="form-control" placeholder="Search for songs or albums" v-model="searchQuery">
          <button class="btn btn-outline-secondary" type="button" @click="search">Search</button>
        </div>
        <ul class="navbar-nav">
          <!-- Route link to the playlist -->
          <li class="nav-item">
            <router-link to="/playlist" class="btn btn-link nav-link">Playlist</router-link>
          </li>
          <li class="nav-item">
            <button class="btn btn-link nav-link" @click="logout">Logout</button>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Songs -->
  <div class="container mt-4">
    <h2 class="display-4 mb-4">Songs</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4">
      <div v-for="song in songs" :key="song.id" class="col">
        <div class="card h-100">
          <div class="card-body">
            <h5 class="card-title">{{ song.name }}</h5>
            <p class="card-text">Genre: {{ song.genre }}</p>
            <button class="btn btn-primary" @click="viewSong(song)">View</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Albums -->
  <div class="container mt-5">
    <h2 class="display-4 mb-4">Albums</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4">
      <div v-for="album in albums" :key="album.id" class="col">
        <div class="card h-100">
          <div class="card-body">
            <h5 class="card-title">{{ album.name }}</h5>
            <p class="card-text">Artist: {{ album.artist }}</p>
            <button class="btn btn-primary" @click="viewAlbum(album)">View</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
`
};