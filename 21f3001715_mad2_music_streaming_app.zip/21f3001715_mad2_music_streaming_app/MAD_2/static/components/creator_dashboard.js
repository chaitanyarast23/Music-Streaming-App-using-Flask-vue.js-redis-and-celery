export default {
  data() {
    return {
      songs: [],
      albums: [],
      newSongName: '',
      newSongLyrics: '',
      newSongGenre: '',
      newSongDuration: '',
      newAlbumName: '',
      newAlbumArtist: '',
      selectedAlbumId: null,
      selectedSongId: null,
      editingAlbumId: null,
      editingSongId: null,
    };
  },
  mounted() {
    this.fetchSongs();
    this.fetchAlbums();
  },
  methods: {
    fetchSongs() {
      axios.get('/song', { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}`,Role: 'creator' } })
        .then(response => {
          this.songs = response.data;
        })
        .catch(error => {
          console.error('Error fetching songs:', error);
        });
    },
    fetchAlbums() {
      axios.get('/album', { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}`,Role: 'creator' } })
        .then(response => {
          this.albums = response.data;
        })
        .catch(error => {
          console.error('Error fetching albums:', error);
        });
    },
    addAlbum() {
      const albumData = {
        name: this.newAlbumName,
        artist: this.newAlbumArtist,
        song_id: this.selectedSongId || null,
      };
      if (this.editingAlbumId) {
        axios.put(`/album/${this.editingAlbumId}`, albumData, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
          .then(response => {
            alert('Album updated successfully!');
            this.fetchAlbums();
            this.resetAlbumForm();
          })
          .catch(error => {
            console.error('Error updating album:', error.response.data);
          });
      } else {
        axios.post('/album', albumData, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
          .then(response => {
            alert('Album added successfully!');
            this.fetchAlbums();
            this.resetAlbumForm();
          })
          .catch(error => {
            console.error('Error adding album:', error.response.data);
          });
      }
    },
    addSong() {
      const songData = {
        name: this.newSongName,
        lyrics: this.newSongLyrics,
        genre: this.newSongGenre,
        duration: this.newSongDuration,
        album_id: this.selectedAlbumId || null,
      };
      if (this.editingSongId) {
        axios.put(`/song/${this.editingSongId}`, songData, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
          .then(response => {
            alert('Song updated successfully!');
            this.fetchSongs();
            this.resetSongForm();
          })
          .catch(error => {
            console.error('Error updating song:', error.response.data);
          });
      } else {
        axios.post('/song', songData, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
          .then(response => {
            alert('Song added successfully!');
            this.fetchSongs();
            this.resetSongForm();
          })
          .catch(error => {
            console.error('Error adding song:', error.response.data);
          });
      }
    },
    viewAlbum(album) {
      this.$router.push({ name: 'album_view', params: { id: album.id } });
    },
    viewSong(song) {
      this.$router.push({ name: 'song_view', params: { id: song.id } });
    },
    editAlbum(album) {
      this.newAlbumName = album.name;
      this.newAlbumArtist = album.artist;
      this.selectedSongId = album.song_id;
      this.editingAlbumId = album.id;
    
      // Fetch all songs associated with the selected album
      axios.get(`/album/${album.id}`, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          const albumSongs = response.data.songs;
          if (!albumSongs.includes(this.selectedSongId)) {
            // If the selected song is not already associated with this album, add it to the album
            albumSongs.push(this.selectedSongId);
            
            // Update the album with the new list of songs
            axios.put(`/album/${album.id}`, { song_ids: albumSongs }, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
              .then(response => {
                console.log('Song added to album successfully!');
              })
              .catch(error => {
                console.error('Error adding song to album:', error);
              });
          }
        })
        .catch(error => {
          console.error('Error fetching album songs:', error);
        });
    },
    deleteAlbum(album) {
      const albumId = album.id;
      axios.delete(`/album/${albumId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          alert('Album deleted successfully!');
          this.fetchAlbums();
        })
        .catch(error => {
          console.error('Error deleting album:', error);
        });
    },
    editSong(song) {
      this.newSongName = song.name;
      this.newSongLyrics = song.lyrics;
      this.newSongGenre = song.genre;
      this.newSongDuration = song.duration;
      this.selectedAlbumId = song.album_id;
      this.editingSongId = song.id;
    },
    deleteSong(song) {
      const songId = song.id;
      axios.delete(`/song/${songId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          alert('Song deleted successfully!');
          this.fetchSongs();
        })
        .catch(error => {
          console.error('Error deleting song:', error);
        });
    },
    resetAlbumForm() {
      this.newAlbumName = '';
      this.newAlbumArtist = '';
      this.selectedSongId = null;
      this.editingAlbumId = null;
    },
    resetSongForm() {
      this.newSongName = '';
      this.newSongLyrics = '';
      this.newSongGenre = '';
      this.newSongDuration = '';
      this.selectedAlbumId = null;
      this.editingSongId = null;
    },
    logout() {
      // Clear the access token from local storage
      localStorage.removeItem('access_token');
      // Redirect to the login page
      this.$router.push('/login');
    }
  },
  template: `
    <div class="container mt-5">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <span class="navbar-brand">Music Magnet</span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <span class="nav-link">Creator Dashboard</span>
                </li>
                <li class="nav-item">
                    <button class="btn btn-link nav-link" @click="logout">Logout</button>
                </li>
            </ul>
        </div>
    </div>
</nav>
      <div class="add-album-section mb-5">
        <h3>Add a New Album</h3>
        <form @submit.prevent="addAlbum" class="mt-3">
          <div class="mb-3">
            <label for="albumName" class="form-label">Album Name:</label>
            <input id="albumName" v-model="newAlbumName" placeholder="Enter album name" class="form-control"/>
          </div>
          <div class="mb-3">
            <label for="albumArtist" class="form-label">Artist:</label>
            <input id="albumArtist" v-model="newAlbumArtist" placeholder="Enter artist name" class="form-control"/>
          </div>
          <div class="mb-3">
            <label for="albumSong" class="form-label">Select Song:</label>
            <select id="albumSong" v-model="selectedSongId" class="form-control">
              <option value="">No Song</option>
              <option v-for="song in songs" :value="song.id" :key="song.id">{{ song.name }}</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary">Add Album</button>
        </form>
      </div>

      <div class="add-song-section mb-5">
        <h3>Add a New Song</h3>
        <form @submit.prevent="addSong" class="mt-3">
          <div class="mb-3">
            <label for="songName" class="form-label">Song Name:</label>
            <input id="songName" v-model="newSongName" placeholder="Enter song name" class="form-control"/>
          </div>
          <div class="mb-3">
            <label for="songLyrics" class="form-label">Lyrics:</label>
            <textarea id="songLyrics" v-model="newSongLyrics" placeholder="Enter lyrics" class="form-control"></textarea>
          </div>
          <div class="mb-3">
            <label for="songGenre" class="form-label">Genre:</label>
            <input id="songGenre" v-model="newSongGenre" placeholder="Enter genre" class="form-control"/>
          </div>
          <div class="mb-3">
            <label for="songDuration" class="form-label">Duration:</label>
            <input id="songDuration" v-model="newSongDuration" placeholder="Enter duration in seconds" type="number" class="form-control"/>
          </div>
          <div class="mb-3">
            <label for="songAlbum" class="form-label">Album:</label>
            <select id="songAlbum" v-model="selectedAlbumId" class="form-control">
              <option value="">No Album</option>
              <option v-for="album in albums" :value="album.id" :key="album.id">{{ album.name }}</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary">Add Song</button>
        </form>
      </div>
      
      <div class="albums-list-section">
        <h3>Your Albums</h3>
        <div v-if="albums.length">
          <ul class="list-group mt-3">
            <li v-for="album in albums" :key="album.id" class="list-group-item">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h5 class="mb-1">{{ album.name }}</h5>
                  <p class="mb-0">Artist: {{ album.artist }}</p>
                </div>
                <div>
                  <button class="btn btn-primary me-2" @click="viewAlbum(album)">View</button>
                  <button class="btn btn-warning me-2" @click="editAlbum(album)">Edit</button>
                  <button class="btn btn-danger" @click="deleteAlbum(album)">Delete</button>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div v-else class="alert alert-info mt-3">
          No albums found. Start adding your creations!
        </div>
      </div>

      <div class="songs-list-section">
        <h3>Your Songs</h3>
        <div v-if="songs.length">
          <ul class="list-group mt-3">
            <li v-for="song in songs" :key="song.id" class="list-group-item">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h5 class="mb-1">{{ song.name }}</h5>
                  <p class="mb-1">Genre: {{ song.genre }}</p>
                  <p class="mb-0">Duration: {{ song.duration }} seconds</p>
                </div>
                <div>
                  <button class="btn btn-primary me-2" @click="viewSong(song)">View</button>
                  <button class="btn btn-warning me-2" @click="editSong(song)">Edit</button>
                  <button class="btn btn-danger" @click="deleteSong(song)">Delete</button>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div v-else class="alert alert-info mt-3">
          No songs found. Start adding your creations!
        </div>
      </div>
    </div>
  `,
};
