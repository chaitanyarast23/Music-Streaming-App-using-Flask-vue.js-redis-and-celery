export default {
  data() {
    return {
      stats: null, // Variable to store fetched statistics
      songs: [], // Array to store fetched songs
      albums: [], // Array to store fetched albums
    };
  },
  mounted() {
    this.fetchStats(); // Fetch statistics when the component is mounted
    this.fetchSongs(); // Fetch songs when the component is mounted
    this.fetchAlbums(); // Fetch albums when the component is mounted
    
    
  },
  watch: {
    // Watching songs array for changes
    songs: {
      handler(newVal) {
        if (newVal.length > 0) {
          this.$nextTick(() => {
            if (document.getElementById('songPerformanceChart')) {
              this.renderChart();
            }
          });
        }
      },
      deep: true,
      immediate: true,
    }
  },
  methods: {
    fetchStats() {
      axios.get('/admin/statistics', { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          this.stats = response.data; // Store fetched statistics in the variable
        })
        .catch(error => {
          console.error('Error fetching statistics:', error);
        });
    },
    fetchSongs() {
      axios.get('/song', { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}`, Role: 'admin' } })
        .then(response => {
          this.songs = response.data;
        })
        .catch(error => {
          console.error('Error fetching songs:', error);
        });
    },
    fetchAlbums() {
      axios.get('/album', { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}`, Role: 'admin' } })
        .then(response => {
          this.albums = response.data;
        })
        .catch(error => {
          console.error('Error fetching albums:', error);
        });
    },
    viewAlbum(album) {
      this.$router.push({ name: 'album_view', params: { id: album.id } });
    },
    viewSong(song) {
      this.$router.push({ name: 'song_view', params: { id: song.id } });
    },
    deleteAlbum(album) {
      const albumId = album.id;
      axios.delete(`/album/${albumId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          alert('Album deleted successfully!');
          this.fetchAlbums();
        })
        .catch(error => {
          console.error('Error deleting album:', error);
        });
    },
    deleteSong(song) {
      const songId = song.id;
      axios.delete(`/song/${songId}`, { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
        .then(response => {
          alert('Song deleted successfully!');
          this.fetchSongs();
        })
        .catch(error => {
          console.error('Error deleting song:', error);
        });
    },
    logout() {
      // Clear the access token from local storage
      localStorage.removeItem('access_token');
      // Redirect to the login page
      this.$router.push('/login');
    },
    triger_celery_job() {
      axios.get("/trigger_csv_generation") // Corrected endpoint
        .then(response => {
          const taskId = response.data['Task ID']; // Adjusted to match Flask response
          console.log("Celery Task Details:", response.data);
          let interval = setInterval(() => {
            axios.get(`/status/${taskId}`)
              .then(response => {
                const taskState = response.data['Task State']; // Adjusted to match Flask response
                if (taskState === "SUCCESS") {
                  console.log("Task finished");
                  clearInterval(interval);
                  // Perform any action after task completion
                } else {
                  console.log("Task still executing");
                }
              })
              .catch(error => {
                console.error("Error checking task status:", error);
                clearInterval(interval); // Stop polling on error
              });
          }, 4000);
        })
        .catch(error => {
          console.error("Error triggering Celery job:", error);
        });
    },
    
    renderChart() {
      const songNames = this.songs.map(song => song.name);
      const totalPlays = this.songs.map(song => song.total_plays);
      const totalLikes = this.songs.map(song => song.total_likes);
      const totalComments = this.songs.map(song => song.total_comments);
      const averageRatings = this.songs.map(song => song.average_rating);

      const ctx = document.getElementById('songPerformanceChart').getContext('2d');

      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: songNames,
          datasets: [
            {
              label: 'Total Plays',
              data: totalPlays,
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 1
            },
            {
              label: 'Total Likes',
              data: totalLikes,
              backgroundColor: 'rgba(54, 162, 235, 0.2)',
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 1
            },
            {
              label: 'Total Comments',
              data: totalComments,
              backgroundColor: 'rgba(255, 206, 86, 0.2)',
              borderColor: 'rgba(255, 206, 86, 1)',
              borderWidth: 1
            },
            {
              label: 'Average Rating',
              data: averageRatings,
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1
            }
          ]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
  },
    template: `
    <div class="container mt-5">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <span class="navbar-brand">Music Magnet</span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <span class="nav-link">Admin Dashboard</span>
            </li>
            <li class="nav-item">
              <button class="btn btn-link nav-link" @click="logout">Logout</button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    
    <div class="row mt-3">
      <div v-if="stats" class="col-md-3">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Total Users</h5>
            <p class="card-text">{{ stats.total_users }}</p>
          </div>
        </div>
      </div>
      <div v-if="stats" class="col-md-3">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Total Creators</h5>
            <p class="card-text">{{ stats.total_creators }}</p>
          </div>
        </div>
      </div>
      <div v-if="stats" class="col-md-3">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Total Albums</h5>
            <p class="card-text">{{ stats.total_albums }}</p>
          </div>
        </div>
      </div>
      <div v-if="stats" class="col-md-3">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Total Songs</h5>
            <p class="card-text">{{ stats.total_songs }}</p>
          </div>
        </div>
      </div>
    </div>
        
    <div class="albums-list-section">
      <h3>Albums</h3>
      <div v-if="albums.length">
        <ul class="list-group mt-3">
          <li v-for="album in albums" :key="album.id" class="list-group-item">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <h5 class="mb-1">{{ album.name }}</h5>
                <p class="mb-0">Artist: {{ album.artist }}</p>
              </div>
              <div>
                <button class="btn btn-primary me-2" @click="viewAlbum(album)">View</button>
                <button class="btn btn-danger" @click="deleteAlbum(album)">Delete</button>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div v-else class="alert alert-info mt-3">
        No albums found. 
      </div>
    </div>
  
    <div class="songs-list-section">
      <h3>Songs</h3>
      <div v-if="songs.length">
        <ul class="list-group mt-3">
          <li v-for="song in songs" :key="song.id" class="list-group-item">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <h5 class="mb-1">{{ song.name }}</h5>
                <p class="mb-1">Genre: {{ song.genre }}</p>
                <p class="mb-0">Duration: {{ song.duration }} seconds</p>
              </div>
              <div>
                <button class="btn btn-primary me-2" @click="viewSong(song)">View</button>
                <button class="btn btn-danger" @click="deleteSong(song)">Delete</button>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div v-else class="alert alert-info mt-3">
        No songs found.
      </div>
    </div>

    <!-- Button for triggering Celery job -->
    <button class="btn btn-primary mt-3" @click="triger_celery_job">Trigger Celery Job</button>

    <div class="chart-section">
      <h3>Song Performance</h3>
      <canvas id="songPerformanceChart" width="400" height="400"></canvas>
    </div>
  </div>
    `,
  };
  