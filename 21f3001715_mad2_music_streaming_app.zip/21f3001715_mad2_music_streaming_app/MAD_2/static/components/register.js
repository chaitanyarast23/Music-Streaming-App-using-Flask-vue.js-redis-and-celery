export default {
  data() {
    return {
      username: '',
      email: '',
      password: '',
      role: 'user',
      creatorPassword: '',  // New field for creator password
      showCreatorPassword: false  // Flag to show creator password input
    };
  },
  methods: {
    registerUser() {
      // Prepare data object based on the selected role
      let data = {
        username: this.username,
        email: this.email,
        password: this.password,
        role: this.role
      };

      // If registering as a creator, include the creator password
      if (this.role === 'creator') {
        if (!this.creatorPassword) {
          console.error('Creator password is required');
          return;
        }
        data.creator_password = this.creatorPassword;
      }

      axios.post('/register', data)
      .then(response => {
        console.log(response.data.message);
        this.$router.push('/login');
      })
      .catch(error => {
        console.error(error.response.data.message);
      });
    },
    toggleCreatorPassword() {
      // Show creator password input only when role is set to 'creator'
      this.showCreatorPassword = this.role === 'creator';
    }
  },
  watch: {
    role() {
      // Toggle creator password input when role changes
      this.toggleCreatorPassword();
    }
  },
  mounted() {
    // Initialize the creator password input visibility
    this.toggleCreatorPassword();
  },
  template: `
    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="card">
            <div class="card-header">
              <h2 class="text-center">Registration Form</h2>
            </div>
            <div class="card-body">
              <form @submit.prevent="registerUser">
                <div class="mb-3">
                  <label for="username" class="form-label">Username:</label>
                  <input type="text" class="form-control" v-model="username" required>
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label">Email:</label>
                  <input type="email" class="form-control" v-model="email" required>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Password:</label>
                  <input type="password" class="form-control" v-model="password" required>
                </div>
                <div v-if="showCreatorPassword" class="mb-3">
                  <label for="creatorPassword" class="form-label">Creator Password:</label>
                  <input type="password" class="form-control" v-model="creatorPassword" required>
                </div>
                <div class="mb-3">
                  <label for="role" class="form-label">Role:</label>
                  <select class="form-select" v-model="role">
                    <option value="user">User</option>
                    <option value="creator">Creator</option>
                  </select>
                </div>
                <button type="submit" class="btn btn-primary">Register</button>
              </form>
            </div>
          </div>
          <div class="text-center mt-3">
            <!-- Link to the login page -->
            <router-link to="/login">Already have an account? Login here</router-link>
            <router-link to="/">Main page</router-link>
          </div>
        </div>
      </div>
    </div>
  `
};
