export default {
  data() {
    return {
      username: '',
      password: '',
      error: ''
    };
  },
  methods: {
    loginUser() {
      console.log('Logging in...');
      console.log('Username:', this.username);
      console.log('Password:', this.password);

      axios.post('http://127.0.0.1:5000/login', {  
        username: this.username,
        password: this.password
      })
      .then(response => {
        console.log('Login successful:', response);
        localStorage.setItem('access_token', response.data.access_token);
        
        // Determine the role of the user
        const role = response.data.role;

        // Redirect based on the user's role
        switch (role) {
          case 'admin':
            this.$router.push('/admin_dashboard');
            break;
          case 'user':
            this.$router.push('/home');
            break;
          case 'creator':
            this.$router.push('/creator_dashboard');
            break;
          default:
            console.error('Unknown role:', role);
            // Redirect to a default page if the role is unknown
            this.$router.push('/');
            break;
        }
      })
      .catch(error => {
        console.error('Login failed:', error);
        // Display error message to the user
        this.error = error.response && error.response.data.message ? error.response.data.message : "Login failed";
      });
    }
  },
  template: `
    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="card">
            <div class="card-header">
              <h2 class="text-center">Login</h2>
            </div>
            <div class="card-body">
              <form @submit.prevent="loginUser">
                <div class="mb-3">
                  <label for="username" class="form-label">Username:</label>
                  <input type="text" class="form-control" v-model="username" required>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Password:</label>
                  <input type="password" class="form-control" v-model="password" required>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
                <!-- Display error message if login fails -->
                <div v-if="error" class="text-danger">{{ error }}</div>
              </form>
            </div>
          </div>
          <div class="text-center mt-3">
            <!-- Link to the registration page -->
            <router-link to="/register">Don't have an account? Register here</router-link>
            <router-link to="/">Main page</router-link>
          </div>
        </div>
      </div>
    </div>
  `
};
