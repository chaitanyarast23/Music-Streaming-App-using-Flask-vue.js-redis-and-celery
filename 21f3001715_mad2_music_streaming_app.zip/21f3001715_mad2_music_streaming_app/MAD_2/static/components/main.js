export default {
    template: `
        <div>
            <!-- Navigation-->
            <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
                <div class="container px-4 px-lg-5">
                    <router-link to="/" class="navbar-brand">Music Magnet</router-link>
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    
                </div>
            </nav>
            <!-- Masthead-->
            <header class="masthead">
                <div class="container px-4 px-lg-5 h-100">
                    <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
                        <div class="col-lg-8 align-self-end">
                            <h1 class="text-white font-weight-bold">Music Magnet</h1>
                            <hr class="divider" />
                        </div>
                        <div class="col-lg-8 align-self-baseline">
                            <p class="text-white-75 mb-5">Let the Music Play On</p>
                            <!-- Use router-link for navigation -->
                            <router-link to="/login" class="btn btn-primary btn-xl">Login</router-link>
                            <router-link to="/register" class="btn btn-primary btn-xl">Register</router-link>
                        </div>
                    </div>
                </div>
            </header>
            <!-- Router View -->
            <router-view></router-view>
        </div>
    `
}
