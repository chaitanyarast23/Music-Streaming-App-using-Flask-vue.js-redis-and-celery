import main from "./components/main.js"
import home from "./components/home.js"
import register from "./components/register.js"; 
import login from "./components/login.js";
import creator_dashboard from "./components/creator_dashboard.js";
import admin_dashboard from "./components/admin_dashboard.js";
import album_view from './components/album_view.js';
import song_view from './components/song_view.js';
import playlist from "./components/playlist.js";

const routes =[
    {path :'/' , component: main},
    {path :'/home' , component: home},
    { path: '/register', component: register },
    { path: '/login', component: login },
    {path:'/creator_dashboard',component:creator_dashboard},
    {path:'/admin_dashboard',component:admin_dashboard},
    { path: '/album/:id', component: album_view, name: 'album_view' },
    { path: '/song/:id', component: song_view, name: 'song_view' },
    { path: '/playlist', component: playlist },
]

export default new VueRouter({
    routes,
})